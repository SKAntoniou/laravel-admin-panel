<x-overview-layout :heading="'Companies'" :itemName="'Company'" :itemRoute="route('company.new')" :array="$companies" :gridBreakpoints="'lg:grid-cols-2'" :type="'company'" :edit="false" :headerAction="'Add'" :headerName="'Company'">
  
</x-overview-layout>

<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['labelTop', 'labelBtn', 'name']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['labelTop', 'labelBtn', 'name']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php if (isset($component)) { $__componentOriginal788c5626c9f4f85906027b3ea3343fab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal788c5626c9f4f85906027b3ea3343fab = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.forms.field','data' => ['label' => $labelTop,'name' => $name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('forms.field'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($labelTop),'name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($name)]); ?>

  <div class="mt-2 flex items-center gap-4">
    <label for="<?php echo e($name); ?>" class="inline-flex items-center rounded-md bg-white px-3 py-1.5 text-base text-gray-900 border border-gray-300 cursor-pointer shadow-sm hover:bg-gray-100 focus:outline-indigo-600 focus:outline-2">
      <?php echo e($labelBtn); ?>

    </label>
    <input id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" type="file" class="hidden" accept="image/png, image/jpeg, image/webp"/>
    <div id="<?php echo e($name); ?>-file-name" class="text-sm text-gray-700 truncate max-w-xs">
      No file chosen
    </div>
  </div>
  <p class="mt-1 text-sm text-gray-500" id="<?php echo e($name); ?>-help">Accepted formats: PNG, JPG, or WEBP.</p>
  
  <script>
    // Forms
    // File Upload
    const fileInput = document.getElementById( 'logo' );
    const fileInfoArea = document.getElementById( 'logo-file-name' );
    fileInput.addEventListener( 'change', (event) => {
      const input = event.srcElement;
      const fileName = input.files[0].name;
      fileInfoArea.textContent = 'File name: ' + fileName;
    });
  </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal788c5626c9f4f85906027b3ea3343fab)): ?>
<?php $attributes = $__attributesOriginal788c5626c9f4f85906027b3ea3343fab; ?>
<?php unset($__attributesOriginal788c5626c9f4f85906027b3ea3343fab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal788c5626c9f4f85906027b3ea3343fab)): ?>
<?php $component = $__componentOriginal788c5626c9f4f85906027b3ea3343fab; ?>
<?php unset($__componentOriginal788c5626c9f4f85906027b3ea3343fab); ?>
<?php endif; ?><?php /**PATH /Users/stephan/Documents/code/netmatters/assessments/laravel_admin_panel/laravel-admin-panel/resources/views/components/forms/file-upload.blade.php ENDPATH**/ ?>
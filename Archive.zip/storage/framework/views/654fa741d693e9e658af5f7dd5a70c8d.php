<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['item', 'itemName', 'type', 'edit'=>false, ]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['item', 'itemName', 'type', 'edit'=>false, ]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="bg-white overflow-hidden shadow-sm rounded-lg flex">
  <?php if(!empty($item->logo)): ?>
    <div class="min-h-[100px] max-h-[200px] min-w-[100px] max-w-[200px] p-2">
      <img class="h-full object-contain" 
        src="<?php echo e(filter_var($item->logo, FILTER_VALIDATE_URL) ? $item->logo : asset($item->logo)); ?>" alt="Company Logo">
    </div>
  <?php endif; ?>
  <div class="p-6 text-gray-900 flex flex-col gap-3 grow">
    <?php if(!empty($item->name)): ?>
      <p><?php echo e($item->name); ?></p>
    <?php elseif(!empty($item->first_name) && !empty($item->last_name)): ?>
      <p><?php echo e($item->first_name . " " . $item->last_name); ?></p>
    <?php endif; ?>
    <p><?php echo e($item->email); ?></p>
    <?php if(!empty($item->phone_number)): ?>
      <p><?php echo e($item->phone_number); ?></p>
    <?php endif; ?>
    <?php if(!empty($item->company)): ?>
      <p><?php echo e($item->company->name); ?></p>
    <?php endif; ?>
    <div class="flex flex-wrap gap-3">
      <?php if(!empty($item->website)): ?>
        <a class="p-3 active:scale-95 transition text-sm text-white rounded-full bg-indigo-500 hover:bg-indigo-600" 
          href="<?php echo e($item->website); ?>">Visit Website</a>
      <?php endif; ?>
      <?php if($edit): ?>
        <a class="p-3 active:scale-95 transition text-sm text-white rounded-full bg-indigo-500 hover:bg-indigo-600"
          href="/<?php echo e($type); ?>/<?php echo e($item->id); ?>/edit">Edit <?php echo e($itemName); ?></a>
      <?php else: ?> 
        <a class="p-3 active:scale-95 transition text-sm text-white rounded-full bg-indigo-500 hover:bg-indigo-600"
          href="/<?php echo e($type); ?>/<?php echo e($item->id); ?>">View <?php echo e($itemName); ?></a>
      <?php endif; ?>
    </div>
  </div>
</div><?php /**PATH /Users/stephan/Documents/code/netmatters/assessments/laravel_admin_panel/laravel-admin-panel/resources/views/components/company-card.blade.php ENDPATH**/ ?>
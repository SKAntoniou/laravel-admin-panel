<form <?php echo e($attributes(["class" => "max-w-7xl mx-auto px-3 sm:px-6 lg:px-8", "method" => "GET"])); ?>>
    <?php if($attributes->get('method', 'GET') !== 'GET'): ?>
        <?php echo csrf_field(); ?>
        <?php echo method_field($attributes->get('method')); ?>
    <?php endif; ?>

    <?php echo e($slot); ?>

</form><?php /**PATH /Users/stephan/Documents/code/netmatters/assessments/laravel_admin_panel/laravel-admin-panel/resources/views/components/forms/form.blade.php ENDPATH**/ ?>
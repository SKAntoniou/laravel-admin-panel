<?php if (isset($component)) { $__componentOriginalf447985daccec3aa9d729b0984c30953 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf447985daccec3aa9d729b0984c30953 = $attributes; } ?>
<?php $component = App\View\Components\OverviewLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('overview-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\OverviewLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Employees'),'itemName' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Employee'),'itemRoute' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('employee.new')),'array' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($employees),'gridBreakpoints' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('md:grid-cols-2 lg:grid-cols-4'),'type' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('employee'),'edit' => true,'headerAction' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Add'),'headerName' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Employee')]); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf447985daccec3aa9d729b0984c30953)): ?>
<?php $attributes = $__attributesOriginalf447985daccec3aa9d729b0984c30953; ?>
<?php unset($__attributesOriginalf447985daccec3aa9d729b0984c30953); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf447985daccec3aa9d729b0984c30953)): ?>
<?php $component = $__componentOriginalf447985daccec3aa9d729b0984c30953; ?>
<?php unset($__componentOriginalf447985daccec3aa9d729b0984c30953); ?>
<?php endif; ?><?php /**PATH /Users/stephan/Documents/code/netmatters/assessments/laravel_admin_panel/laravel-admin-panel/resources/views/employee/index.blade.php ENDPATH**/ ?>